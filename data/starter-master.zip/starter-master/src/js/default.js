// Default Javascript File
console.log('Base starter, ready to rock and roll!');